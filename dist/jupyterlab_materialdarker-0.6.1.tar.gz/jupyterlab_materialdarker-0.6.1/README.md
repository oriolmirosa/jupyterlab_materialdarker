# Material Darker JupyterLab Extension

This is my port of the [Material Darker theme](http://equinsuocha.io/material-theme/#/darker) for JupyterLab. It's a work in progress.

The extension has now been updated to support JupyterLab 3.x.

## Install

From npm:
```
jupyter labextension install @oriolmirosa/jupyterlab_materialdarker
```

or directly from PyPi:
```
pip install jupyterlab_materialdarker
```

After launching JupyterLab, select the `Material Darker` theme from the main menu: `Settings` > `JupyterLab Theme` > `Material Darker`


![The Material Darker theme on JupyterLab](https://user-images.githubusercontent.com/6955013/37124604-0450d6dc-2237-11e8-95d8-0e822ee92c49.png)
